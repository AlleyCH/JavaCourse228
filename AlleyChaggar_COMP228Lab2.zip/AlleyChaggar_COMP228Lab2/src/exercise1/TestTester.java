package exercise1;

import javax.swing.JOptionPane;

public class TestTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String test = Test.simulateQuestion();
		String Input1 = JOptionPane.showInputDialog(test);
		
	}
}
