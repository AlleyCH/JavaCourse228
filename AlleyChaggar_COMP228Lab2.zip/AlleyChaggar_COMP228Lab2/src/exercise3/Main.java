package exercise3;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(Java.overLoad(null));
		System.out.println(Java.overLoad("Alley", "Hello world!"));
		System.out.println(Java.overLoad());	
	}
	
}
